self.assetsManifest = {
  "version": "TzWsaJWq",
  "assets": [
    {
      "hash": "sha256-54UpmXAxGWZtgyUBi//q8jeTaWJ3yEQAfX0HZnanbfg=",
      "url": "BlazorLocalStorageSample.styles.css"
    },
    {
      "hash": "sha256-HxwKoVctK+wQ0HiT11O9AmUYSA+81DbllK+r1K1NTMI=",
      "url": "_framework/BlazorLocalStorageSample.3728fotrzr.wasm"
    },
    {
      "hash": "sha256-OaMAAd5n7ORfyur5e3QIyEVKJ76MKIvwbg7/icnnYcU=",
      "url": "_framework/Blazored.LocalStorage.12n6dz54qr.wasm"
    },
    {
      "hash": "sha256-E+Mt2ZudWTjGMLQsukw6qCNFOIHlFp8txQmPHDNWw0w=",
      "url": "_framework/Microsoft.AspNetCore.Components.Forms.tsij7kcdu0.wasm"
    },
    {
      "hash": "sha256-YCahldhedjKdSRHY0sbyRul0Gykxn/+Aca10eUO8ty0=",
      "url": "_framework/Microsoft.AspNetCore.Components.Web.kfrjg2fad1.wasm"
    },
    {
      "hash": "sha256-K4H030gkTHmaCEJlY5dOMaLEJ7KcGQRM+DuB3mH4L1A=",
      "url": "_framework/Microsoft.AspNetCore.Components.WebAssembly.di87cb8hf5.wasm"
    },
    {
      "hash": "sha256-Nttz8lbE9WLqGR1pLei1siYX/ED63dx09wK3AlMmZCc=",
      "url": "_framework/Microsoft.AspNetCore.Components.iqx4hgjep7.wasm"
    },
    {
      "hash": "sha256-O/18yK/3Pj3wG2PLVJBN283TmIjoQ5k/JAdb5d/O+P8=",
      "url": "_framework/Microsoft.Extensions.Configuration.Abstractions.h19gpugiy5.wasm"
    },
    {
      "hash": "sha256-7Wv00KMrZAHb5sX5acrBZ6dNoPfDuaNWlT69VNMGt1g=",
      "url": "_framework/Microsoft.Extensions.Configuration.Json.n3x20s9cxz.wasm"
    },
    {
      "hash": "sha256-XhpSYR8F8A+kKAi/mojMfR/OreGPs3bc2GIu2PE9098=",
      "url": "_framework/Microsoft.Extensions.Configuration.icatoxhjsq.wasm"
    },
    {
      "hash": "sha256-UWOGokSU1FLeq9lG/LcE7ayw67nv9LiWWU5+RJsZ9hI=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.Abstractions.z71un98m5s.wasm"
    },
    {
      "hash": "sha256-DnnRKy8PZBHtfhziO6DfIwoozcHbfQiGwcXDh5nRSZc=",
      "url": "_framework/Microsoft.Extensions.DependencyInjection.qeizni4cln.wasm"
    },
    {
      "hash": "sha256-vlxtm3yBuS3MLAQ5+4ScvtwEhiUALJWodBcztlvIMoA=",
      "url": "_framework/Microsoft.Extensions.Logging.Abstractions.m389qeoxh3.wasm"
    },
    {
      "hash": "sha256-TusUfPjSxh0GzZINX/Xk9afg45BQccmXJOyvulCHlU4=",
      "url": "_framework/Microsoft.Extensions.Logging.e47xhy91y6.wasm"
    },
    {
      "hash": "sha256-muT+1idbPdv4l3tZ03AMNKOMBk1naU8HsjiH1fugp08=",
      "url": "_framework/Microsoft.Extensions.Options.2tpvz1izx7.wasm"
    },
    {
      "hash": "sha256-6cQKFBXogCgICQbWptUlzgW+xOHIWbUMRjFxztqytdA=",
      "url": "_framework/Microsoft.Extensions.Primitives.9kx4ehp8td.wasm"
    },
    {
      "hash": "sha256-NNwR0xu2wKvvEIZnSUwKht+/0RJ9ziHW01M66VViIkI=",
      "url": "_framework/Microsoft.JSInterop.WebAssembly.s0bw0921jm.wasm"
    },
    {
      "hash": "sha256-oapEEcis16PER4H+NWSRfblFDd3EHotjtBHdMjKDL+E=",
      "url": "_framework/Microsoft.JSInterop.v4z6ynce6a.wasm"
    },
    {
      "hash": "sha256-4FcHcBsl4uLksLgt7Rj0XhxKV520tXAcf/xK6lWdASc=",
      "url": "_framework/System.Collections.0cn8knbu8d.wasm"
    },
    {
      "hash": "sha256-o2kBnl2aFbVA1J1+xZn31vVNCUT+H1TecMQNTL3FKLs=",
      "url": "_framework/System.Collections.Concurrent.7f0usc4ymu.wasm"
    },
    {
      "hash": "sha256-RsJ2q2FQEu/yI4DHjLL5PchzdAgg0kux7YfEYCGaNKg=",
      "url": "_framework/System.Collections.Immutable.ef1yu5ny8p.wasm"
    },
    {
      "hash": "sha256-hiCNLBMli9ZrBjl0l9NVvcXG36xkGJF/znLqDS6yYxs=",
      "url": "_framework/System.Collections.NonGeneric.6o2wb88be1.wasm"
    },
    {
      "hash": "sha256-eBgVl2IwotIOe+NqG9flo/g+TPFKXGkmvcLkOwkyl7s=",
      "url": "_framework/System.Collections.Specialized.kxwvs9knkq.wasm"
    },
    {
      "hash": "sha256-JNR/o2tUFaDeOk9pghPZD2sAdWEKA2OUJ2ONln9UeD0=",
      "url": "_framework/System.ComponentModel.076m38u6l8.wasm"
    },
    {
      "hash": "sha256-rN/lNzgrBfb0FFVSaK7wSBRhi4SMszehXWb5XDGLzo4=",
      "url": "_framework/System.ComponentModel.Annotations.oz97qajg2z.wasm"
    },
    {
      "hash": "sha256-iFx3H2Y8f83u8ryMCirSl02dKmvxq5hxOsl5M3r14pc=",
      "url": "_framework/System.ComponentModel.Primitives.gu38u435ry.wasm"
    },
    {
      "hash": "sha256-lfstJvZu4KOfGst2YrqKkXsRSACt61zZb7S3HXo2kMs=",
      "url": "_framework/System.ComponentModel.TypeConverter.z6j5se0my0.wasm"
    },
    {
      "hash": "sha256-fGyCR/qobHBtz6LQcJpp3iL+z+lvD32xQNkLIfxCEmw=",
      "url": "_framework/System.Console.s4p9ht4o57.wasm"
    },
    {
      "hash": "sha256-8NykjQPqDkEb8MybywkzTKLeF69Y61NlxLdJvCVC8wQ=",
      "url": "_framework/System.Diagnostics.DiagnosticSource.4ftkfrxd4q.wasm"
    },
    {
      "hash": "sha256-uEVVMYx7abWgasKfPzSB6wOMoCpVEVv4EcEAOCa4ph0=",
      "url": "_framework/System.IO.Pipelines.0uhw8kopg1.wasm"
    },
    {
      "hash": "sha256-zGRGoHOUaXGsx8DpEB/8BQZ+fhgU1cmL3AGA97paNvk=",
      "url": "_framework/System.Linq.8vdcunv1ej.wasm"
    },
    {
      "hash": "sha256-y1WuK0s3rWj1fqt2B95oirSfiWDqd2QzvbHs3vE2LMk=",
      "url": "_framework/System.Linq.Expressions.5keaquv3f9.wasm"
    },
    {
      "hash": "sha256-tCznIAaQdysSsBlri4JhpkOJQ4Nhsopc01TKAJP/ByY=",
      "url": "_framework/System.Memory.gxk30wm3qo.wasm"
    },
    {
      "hash": "sha256-uaDJXUjtVrPMO5gJ5/dikCyyZpnq9v69Cd/kmBYzqkE=",
      "url": "_framework/System.Net.Http.Json.firoqhkdnq.wasm"
    },
    {
      "hash": "sha256-fjDSVopACmdB0Xiz8UHbmXqfTDjPDwJoXKWdKBSJfeU=",
      "url": "_framework/System.Net.Http.yz3pwg37l3.wasm"
    },
    {
      "hash": "sha256-nezaQh05iG5l4rQswqNPl/zET8UwMn5b44CpxdCrhyQ=",
      "url": "_framework/System.Net.Primitives.9x72ktbyas.wasm"
    },
    {
      "hash": "sha256-wNfPvrHDu12m8nAsDGzNZQk23FT+Jj3h9Ewtkzk8Yuc=",
      "url": "_framework/System.ObjectModel.wgm2i2b0yp.wasm"
    },
    {
      "hash": "sha256-QiLTxhSZSRf/KjJq5pZ9WNoqHuQsXK5zkdNi4PHnh+0=",
      "url": "_framework/System.Private.CoreLib.ibutrdh9df.wasm"
    },
    {
      "hash": "sha256-3Tp5I1CTHlpuBN+pb8vwGC5u+mDb3ar8wyokKvyHPw8=",
      "url": "_framework/System.Private.Uri.137ccgcklz.wasm"
    },
    {
      "hash": "sha256-uo4WQ39eiOB+w/weMzCVCfXQey09VlzpTm+e6aR83IA=",
      "url": "_framework/System.Runtime.InteropServices.JavaScript.era55l3sbb.wasm"
    },
    {
      "hash": "sha256-NmYMQHBLs7lgIXDfLv3qMr2BXadxAMWLjqs3C6djLCw=",
      "url": "_framework/System.Runtime.Serialization.Primitives.6wjui9dnma.wasm"
    },
    {
      "hash": "sha256-+LBHoc05YhNo9R383vqkT4aPMR9lNVXdk0cyMkI22zQ=",
      "url": "_framework/System.Runtime.w29kqf1xuj.wasm"
    },
    {
      "hash": "sha256-pdKoJJI3yt1NF2Lx1MGO++1RtPSzree8qeWFFtJOnKo=",
      "url": "_framework/System.Text.Encodings.Web.5w28q6ifw5.wasm"
    },
    {
      "hash": "sha256-fS/v6/Oek0m5fggWiQ/MjxczyPRoYRWbcBvor+qqPJY=",
      "url": "_framework/System.Text.Json.77o45afgtk.wasm"
    },
    {
      "hash": "sha256-A29j8BigKS89/5EBW6GETUPxSN+JNi8uuKehrofYFmE=",
      "url": "_framework/System.Text.RegularExpressions.3kr2n0wcz9.wasm"
    },
    {
      "hash": "sha256-F5PSI/gBuwoWEF7SbdO7+2/Lo9hw0ISBKug8avOpxP0=",
      "url": "_framework/System.Threading.vuopdrx302.wasm"
    },
    {
      "hash": "sha256-v1DeJU321NUwk3KJ0Lf8lQA3zwRfrxNommmMBs1s3Gk=",
      "url": "_framework/System.f0fr8djds0.wasm"
    },
    {
      "hash": "sha256-FbPErM2CGGzV/FT/yukNKVFSZAv8Fq9kTxEdQz7RB+E=",
      "url": "_framework/blazor.boot.json"
    },
    {
      "hash": "sha256-+vIfWRbrna1rF+s8xknbrluJxgPx4vfKB0WJ74HdICo=",
      "url": "_framework/blazor.webassembly.js"
    },
    {
      "hash": "sha256-5TAd2is0AgjjYIAuEN8Bd5ZPoTk8dKE9RRtIQr4H5Lw=",
      "url": "_framework/dotnet.js"
    },
    {
      "hash": "sha256-89jyB8DlCnV2BPMV477jOe1Sm0WXwVf8RuoSPsj4Ym8=",
      "url": "_framework/dotnet.native.3c4wvb350q.wasm"
    },
    {
      "hash": "sha256-LX9rFEWGVxhkOkAVPG0w5RxPwzPBlEUz6dQNjWS7M+M=",
      "url": "_framework/dotnet.native.hvg7u8bimp.js"
    },
    {
      "hash": "sha256-dCmS9Zx4egtLYSUgTI3R6gMS+Yg8MkzxW1CgEMJKAEw=",
      "url": "_framework/dotnet.runtime.cymp1amu5g.js"
    },
    {
      "hash": "sha256-SZLtQnRc0JkwqHab0VUVP7T3uBPSeYzxzDnpxPpUnHk=",
      "url": "_framework/icudt_CJK.tjcz0u77k5.dat"
    },
    {
      "hash": "sha256-8fItetYY8kQ0ww6oxwTLiT3oXlBwHKumbeP2pRF4yTc=",
      "url": "_framework/icudt_EFIGS.tptq2av103.dat"
    },
    {
      "hash": "sha256-L7sV7NEYP37/Qr2FPCePo5cJqRgTXRwGHuwF5Q+0Nfs=",
      "url": "_framework/icudt_no_CJK.lfu7j35m59.dat"
    },
    {
      "hash": "sha256-vGbjgqEqv4y3q5OB8W2R9LthkuF8mQfHFeNdKSReSmU=",
      "url": "css/app.css"
    },
    {
      "hash": "sha256-4mWsDy3aHl36ZbGt8zByK7Pvd4kRUoNgTYzRnwmPHwg=",
      "url": "favicon.png"
    },
    {
      "hash": "sha256-DbpQaq68ZSb5IoPosBErM1QWBfsbTxpJqhU0REi6wP4=",
      "url": "icon-192.png"
    },
    {
      "hash": "sha256-oEo6d+KqX5fjxTiZk/w9NB3Mi0+ycS5yLwCKwr4IkbA=",
      "url": "icon-512.png"
    },
    {
      "hash": "sha256-Uqu5j+Y5qyPCD2aYEtKQVkTrSztb2ZMjYi4SC0TV2LQ=",
      "url": "index.html"
    },
    {
      "hash": "sha256-Yy5/hBqRmmU2MJ1TKwP2aXoTO6+OjzrLmJIsC2Wy4H8=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css"
    },
    {
      "hash": "sha256-xAT+n25FE5hvOjj2fG4YdOwr1bl4IlAJBNg6PbhLT2E=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.css.map"
    },
    {
      "hash": "sha256-5nDHMGiyfZHl3UXePuhLDQR9ncPfBR1HJeZLXyJNV24=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css"
    },
    {
      "hash": "sha256-kgL+xwVmM8IOs15lnoHt9daR2LRMiBG/cYgUPcKQOY4=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.min.css.map"
    },
    {
      "hash": "sha256-CZxoF8zjaLlyVkcvVCDlc8CeQR1w1RMrvgYx30cs8kM=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css"
    },
    {
      "hash": "sha256-/siQUA8yX830j+cL4amKHY3yBtn3n8z3Eg+VZ15f90k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.css.map"
    },
    {
      "hash": "sha256-vMxTcvkC4Ly7LiAT3G8yEy9EpTr7Fge4SczWp07/p3k=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css"
    },
    {
      "hash": "sha256-7GdOlw7U/wgyaeUtFmxPz5/MphdvVSPtVOOlTn9c33Q=",
      "url": "lib/bootstrap/dist/css/bootstrap-grid.rtl.min.css.map"
    },
    {
      "hash": "sha256-lo9YI82OF03vojdu+XOR3+DRrLIpMhpzZNmHbM5CDMA=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css"
    },
    {
      "hash": "sha256-RXJ/QZiBfHXoPtXR2EgC+bFo2pe3GtbZO722RtiLGzQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.css.map"
    },
    {
      "hash": "sha256-l8vt5oozv958eMd9TFsPAWgl9JJK9YKfbVSs8mchQ84=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css"
    },
    {
      "hash": "sha256-0eqVT62kqRLJh9oTqLeIH4UnQskqVjib8hl2fXxl4lg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.min.css.map"
    },
    {
      "hash": "sha256-V8psnHoJS/MPlCXWwc/J3tGtp9c3gGFRmqsIQgpn+Gg=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css"
    },
    {
      "hash": "sha256-OoQVwh7Arp7bVoK2ZiTx2S//KrnPrSPzPZ93CqCMhe8=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.css.map"
    },
    {
      "hash": "sha256-/8jh8hcEMFKyS6goWqnNu7t3EzZPCGdQZgO6sCkI8tI=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css"
    },
    {
      "hash": "sha256-910zw+rMdcg0Ls48ATp65vEn8rd5HvPxOKm2x3/CBII=",
      "url": "lib/bootstrap/dist/css/bootstrap-reboot.rtl.min.css.map"
    },
    {
      "hash": "sha256-2BubgNUPlQSF/0wLFcRXQ/Yjzk9vsUbDAeK2QM+h+yo=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css"
    },
    {
      "hash": "sha256-Nfjrc4Ur9Fv2oBEswQWIyBnNDP99q+LhL+z9553O0cY=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.css.map"
    },
    {
      "hash": "sha256-KyE9xbKO9CuYx0HXpIKgsWIvXkAfITtiQ172j26wmRs=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css"
    },
    {
      "hash": "sha256-rHDmip4JZzuaGOcSQ1QSQrIbG0Eb3Zja9whqSF1zYIU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.min.css.map"
    },
    {
      "hash": "sha256-H6wkBbSwjua2veJoThJo4uy161jp+DOiZTloUlcZ6qQ=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css"
    },
    {
      "hash": "sha256-p0BVq5Ve/dohBIdfbrZsoQNu02JSsKh1g0wbyiQiUaU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.css.map"
    },
    {
      "hash": "sha256-GAUum6FjwQ8HrXGaoFRnHTqQQLpljXGavT7mBX8E9qU=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css"
    },
    {
      "hash": "sha256-o8XK32mcY/FfcOQ1D2HJvVuZ0YTXSURZDLXCK0fnQeA=",
      "url": "lib/bootstrap/dist/css/bootstrap-utilities.rtl.min.css.map"
    },
    {
      "hash": "sha256-GKEF18s44B5e0MolXAkpkqLiEbOVlKf6VyYr/G/E6pw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css"
    },
    {
      "hash": "sha256-KzNVR3p7UZGba94dnCtlc6jXjK5urSPiZ/eNnKTmDkw=",
      "url": "lib/bootstrap/dist/css/bootstrap.css.map"
    },
    {
      "hash": "sha256-PI8n5gCcz9cQqQXm3PEtDuPG8qx9oFsFctPg0S5zb8g=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css"
    },
    {
      "hash": "sha256-8SM4U2NQpCLGTQLW5D/x3qSTwxVq2CP+GXYc3V1WwFs=",
      "url": "lib/bootstrap/dist/css/bootstrap.min.css.map"
    },
    {
      "hash": "sha256-j5E4XIj1p1kNnDi0x1teX9RXoh1/FNlPvCML9YmRh2Q=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css"
    },
    {
      "hash": "sha256-3bYWUiiVYMZfv2wq5JnXIsHlQKgSKs/VcRivgjgZ1ho=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.css.map"
    },
    {
      "hash": "sha256-h5lE7Nm8SkeIpBHHYxN99spP3VuGFKl5NZgsocil7zk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css"
    },
    {
      "hash": "sha256-rTzXlnepcb/vgFAiB+U7ODQAfOlJLfM3gY6IU7eIANk=",
      "url": "lib/bootstrap/dist/css/bootstrap.rtl.min.css.map"
    },
    {
      "hash": "sha256-yRnLaK5u6HrbYgM9WpjI+gjc8D8lHGzm5CyK1YWkcAw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js"
    },
    {
      "hash": "sha256-o0U5Sti6e4oyV/KLdis2sWh1lmv4jYHy36o5/YK2QEM=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.js.map"
    },
    {
      "hash": "sha256-CDOy6cOibCWEdsRiZuaHf8dSGGJRYuBGC+mjoJimHGw=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js"
    },
    {
      "hash": "sha256-SfllRYIcY+8Y3YGogpq1+c3PdKJF8CzpkxH8NZfbY5c=",
      "url": "lib/bootstrap/dist/js/bootstrap.bundle.min.js.map"
    },
    {
      "hash": "sha256-1lBYhuydh5oGPlYsMm2O/JEFubzcPVcGJFnTfj/9rKU=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js"
    },
    {
      "hash": "sha256-UEsNOeSMvxsBkkann3AFqmyVxZVlOhYfVAS5JtS2nvA=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.js.map"
    },
    {
      "hash": "sha256-QZdFT1ZNdly4rmgUBtXmXFS9BU1FTa+sPe6h794sFRQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js"
    },
    {
      "hash": "sha256-jmWHRhes4frZUmfg7SKXe166pDATfNBIP+0xRa5/NQM=",
      "url": "lib/bootstrap/dist/js/bootstrap.esm.min.js.map"
    },
    {
      "hash": "sha256-Tqa/MpCnccwpStxfBierN2dLK50nlzaW1MUIJtJ+XdE=",
      "url": "lib/bootstrap/dist/js/bootstrap.js"
    },
    {
      "hash": "sha256-gonP394iPL+gDmnoOYoCpWnBeDBw4NNuGea6MEh6GZ4=",
      "url": "lib/bootstrap/dist/js/bootstrap.js.map"
    },
    {
      "hash": "sha256-3gQJhtmj7YnV1fmtbVcnAV6eI4ws0Tr48bVZCThtCGQ=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js"
    },
    {
      "hash": "sha256-D3cnvcSag+Yl0o8EF4DKbojUg4dexslQKbaqyzNJGcA=",
      "url": "lib/bootstrap/dist/js/bootstrap.min.js.map"
    },
    {
      "hash": "sha256-ZTADaSGUu6bF0lNygFTu97N0Vw0Q4YtO/1hZyujXVsM=",
      "url": "manifest.webmanifest"
    },
    {
      "hash": "sha256-enKgCMkYmCpfEcmg6Annbmc40VZ/A6aYYSQjZfVn2cU=",
      "url": "sample-data/weather.json"
    }
  ]
};
